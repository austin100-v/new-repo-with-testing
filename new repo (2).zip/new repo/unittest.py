import unittest
from datetime import date, timedelta
from battery.battery.py import Battery
from engine.engine.py import Engine
from CarFactory.CarFactory.py  import CarFactory



class TestCapuletEngine(unittest.TestCase):
    def test_needs_service_true(self):
        engine = CapuletEngine(last_service_mileage=0, current_mileage=40000)
        self.assertTrue(engine.needs_service())

    def test_needs_service_false(self):
        engine = CapuletEngine(last_service_mileage=0, current_mileage=20000)
        self.assertFalse(engine.needs_service())

class TestSternmanEngine(unittest.TestCase):
    def test_needs_service_true(self):
        engine = SternmanEngine(warning_light_on=True)
        self.assertTrue(engine.needs_service())

    def test_needs_service_false(self):
        engine = SternmanEngine(warning_light_on=False)
        self.assertFalse(engine.needs_service())

class TestWilloughbyEngine(unittest.TestCase):
    def test_needs_service_true(self):
        engine = WilloughbyEngine(last_service_mileage=0, current_mileage=70000)
        self.assertTrue(engine.needs_service())

    def test_needs_service_false(self):
        engine = WilloughbyEngine(last_service_mileage=0, current_mileage=50000)
        self.assertFalse(engine.needs_service())

class TestSpindlerBattery(unittest.TestCase):
    def test_needs_service_true(self):
        last_service_date = date.today() - timedelta(days=2*365 + 1)
        battery = SpindlerBattery(last_service_date=last_service_date, current_date=date.today())
        self.assertTrue(battery.needs_service())

    def test_needs_service_false(self):
        last_service_date = date.today() - timedelta(days=2*365 - 1)
        battery = SpindlerBattery(last_service_date=last_service_date, current_date=date.today())
        self.assertFalse(battery.needs_service())

class TestNubbinBattery(unittest.TestCase):
    def test_needs_service_true(self):
        last_service_date = date.today() - timedelta(days=4*365 + 1)
        battery = NubbinBattery(last_service_date=last_service_date, current_date=date.today())
        self.assertTrue(battery.needs_service())

    def test_needs_service_false(self):
        last_service_date = date.today() - timedelta(days=4*365 - 1)
        battery = NubbinBattery(last_service_date=last_service_date, current_date=date.today())
        self.assertFalse(battery.needs_service())

class TestCarModels(unittest.TestCase):
    def test_calliope_needs_service(self):
        engine = CapuletEngine(last_service_mileage=0, current_mileage=40000)
        battery = SpindlerBattery(last_service_date=date.today() - timedelta(days=2*365 + 1), current_date=date.today())
        car = Car(engine, battery)
        self.assertTrue(car.needs_service())

    def test_glissade_needs_service(self):
        engine = WilloughbyEngine(last_service_mileage=0, current_mileage=70000)
        battery = SpindlerBattery(last_service_date=date.today() - timedelta(days=2*365 + 1), current_date=date.today())
        car = Car(engine, battery)
        self.assertTrue(car.needs_service())

    def test_palindrome_needs_service(self):
        engine = SternmanEngine(warning_light_on=True)
        battery = SpindlerBattery(last_service_date=date.today() - timedelta(days=2*365 + 1), current_date=date.today())
        car = Car(engine, battery)
        self.assertTrue(car.needs_service())

    def test_rorschach_needs_service(self):
        engine = WilloughbyEngine(last_service_mileage=0, current_mileage=70000)
        battery = NubbinBattery(last_service_date=date.today() - timedelta(days=4*365 + 1), current_date=date.today())
        car = Car(engine, battery)
        self.assertTrue(car.needs_service())

    def test_thovex_needs_service(self):
        engine = CapuletEngine(last_service_mileage=0, current_mileage=40000)
        battery = NubbinBattery(last_service_date=date.today() - timedelta(days=4*365 + 1), current_date=date.today())
        car = Car(engine, battery)
        self.assertTrue(car.needs_service())

if __name__ == '__main__':
    unittest.main()
