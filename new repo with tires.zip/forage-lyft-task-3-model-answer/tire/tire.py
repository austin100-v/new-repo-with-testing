from abc import ABC, abstractmethod
from datetime import date, timedelta

class Tire(ABC):
    @abstractmethod
    def needs_service(self) -> bool:
        pass