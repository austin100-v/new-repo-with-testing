from abc import ABC, abstractmethod
from datetime import date, timedelta
from tire.tire.py import Tire


class CarriganTires(Tire):
    def __init__(self, tire_wear: list):
        self.tire_wear = tire_wear

    def needs_service(self) -> bool:
        return any(wear >= 0.9 for wear in self.tire_wear)

